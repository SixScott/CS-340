from pymongo import MongoClient
from bson.objectid import ObjectId

class AnimalShelter(object):
    """CRUD operations for Animal collection in MongoDB"""
    
    
    def __init__(self, username, password):
        # Initaializing the MongoClient. This helps to
        # access the MongoDB databases and collections.
        
        self.client = MongoClient('mongodb://%s:%s@localhost:53354/AAC' % ("aacuser", "password"))
        self.database = self.client['AAC']
       
  # Complete this create method to implement the C in CRUD.
    def create(self, data):
        
        if data is not None:
            insertSuccess= self.database.animals.insert(data)  #data should be dictionary
            if insertSuccess != 0:
                return False
            
            return True
            
        else:
            raise Exception("Nothing to save, because data parameter is empty")
                   
          
   # Complete this create method to implement the R in CRUD.
    def readAll(self, searchData):
        
        if searchData:
            data = self.database.animals.find(searchData, {"_id": False}) 
            
        else:
            data = self.database.animals.find({}, {"_id": False})
            
        return data
  # Complete this update method to implement the U in CRUD.
    def update(self, searchData, dataUpdate):
        
        if data is not None:
            data = self.database.animals.update_many(searchData, {"$set": updateDate}) 
        else:
            return "{}"
            
        return result.raw_result
    
   # Complete this delete method to implement the D in CRUD.
    def delete(self, deleteData):
        
        if data is not None:
            result = self.database.animals.delete_many(deleteData)            
        else:
            return "{}"
        
        return result.raw_result
    